#pragma once
#include <string>
using namespace std;
class FileNotFoundException
{
public:
	FileNotFoundException(string message);
};